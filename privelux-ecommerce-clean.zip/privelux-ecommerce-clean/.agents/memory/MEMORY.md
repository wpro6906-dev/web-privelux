# Memory Index

- [Vercel re-import backup restore](vercel-reimport-backup.md) — imported ".migration-backup" can be a real prior Replit app, not raw Next.js; check before converting.
