---
name: Vercel re-import backup restore
description: What to check when a "port Vercel app to Replit" task actually contains a prior Replit pnpm-workspace project under .migration-backup.
---

When a migration task's `.migration-backup` folder contains `replit.md`, `.replit`, and `artifacts/{...}` with the pnpm-workspace layout, the "Vercel app" was originally built on Replit, exported to Vercel (has `vercel.json`), and is now being re-imported — it is NOT a raw Next.js app needing framework conversion. Treat it as a restore/merge: diff the fresh scaffold against the backup and copy real routes/schema/frontend source back in, rather than following Next.js→Vite conversion steps.

**Why:** Following the generic Vercel-port conversion guide here would have discarded a fully-built Express+Drizzle+React app and rebuilt it from scratch unnecessarily.

**How to apply:** Before starting a Vercel-port task, inspect the backup root for Replit-specific markers (`.replit`, `replit.md`, `attached_assets/`, `artifacts/*/.replit-artifact/artifact.toml`). If found, diff each artifact/lib against the fresh scaffold and restore real content (schema files, API routes, openapi.yaml, frontend src/public) instead of converting framework code.

Also watch for stray `.replit-artifact/artifact.toml` files left inside the backup copy — Replit's artifact scanner will auto-register those as duplicate artifacts/workflows even though they live under a non-live backup directory. Delete those `.replit-artifact` folders inside the backup to stop the duplicate registration (confirmed: removing them causes the platform to automatically drop the extra workflows).

If the backup also includes a `pg_dump` SQL file with real product/user data, restore just the `COPY ... FROM stdin` data sections via `psql "$DATABASE_URL" -f <extracted-data-only-file>` after schema is created via `drizzle-kit push` — running the full dump (with its DDL) will collide with tables Drizzle already created.
